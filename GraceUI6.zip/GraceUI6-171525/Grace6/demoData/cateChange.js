export default {
	products : [
		{ cateid: 1, name: '分类 · 01' , products:[
			{id:11,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:12,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:13,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:14,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:15,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:16,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 2, name: '分类 · 02', products:[
			{id:21,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:22,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:23,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:24,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:25,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:26,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 3, name: '分类 · 03' ,products:[
			{id:31,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:32,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:33,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:34,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:35,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:36,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 4, name: '分类 · 04' ,products:[
			{id:41,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:42,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:43,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:44,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:45,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:46,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 5, name: '分类 · 05' ,products:[
			{id:51,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:52,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:53,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:54,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:55,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:56,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 6, name: '分类 · 06' ,products:[
			{id:61,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:62,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:63,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:64,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:65,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:66,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 7, name: '分类 · 07' ,products:[
			{id:71,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:72,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:73,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:74,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:75,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:76,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 8, name: '分类 · 08' ,products:[
			{id:81,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:82,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:83,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:84,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:85,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:86,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 9, name: '分类 · 09' ,products:[
			{id:91,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:92,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:93,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:94,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:95,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:96,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 10, name: '分类 · 10' ,products:[
			{id:101,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:102,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:103,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:104,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:105,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:106,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 11, name: '分类 · 11' ,products:[
			{id:111,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:112,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:113,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:114,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:115,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:116,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]},
		{ cateid: 12, name: '分类 · 12' ,products:[
			{id:121,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/28.png',price:12.88},
			{id:122,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/29.png',price:12.88},
			{id:123,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/30.png',price:12.88},
			{id:124,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/31.png',price:12.88},
			{id:125,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/34.png',price:12.88},
			{id:126,name:"标题",img:'https://cmsuse.oss-cn-beijing.aliyuncs.com/g5/37.png',price:12.88}
		]}
	]
}