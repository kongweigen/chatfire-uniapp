<template>
	<view 
	class="gui-flex gui-column gui-justify-content-center gui-align-items-center">
		<slot name="img"></slot>
		<slot name="text"></slot>
		<slot name="other"></slot>
	</view>
</template>
<script>
</script>
<style scoped>
</style>