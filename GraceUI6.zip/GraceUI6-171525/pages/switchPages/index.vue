<template>
	<gui-page :customHeader="true">
		<template v-slot:gHeader>
			<!-- #ifdef MP -->
			<view style="height:20px;"></view>
			<!-- #endif -->
		</template>
		<!-- 请开始您的开发 ~ -->
		<template v-slot:gBody>
			<view class="gui-padding">
				<view>
					<logo></logo>
				</view>
				<view class="gui-margin-top">
					<page-demo></page-demo>
				</view>
				<view style="height:30rpx;"></view>
			</view>
		</template>
	</gui-page>
</template>
<script>
export default {
	data() { 
		return {
			
		}
	},
	methods: {
		
	}
}
</script>
<style scoped>
</style>
